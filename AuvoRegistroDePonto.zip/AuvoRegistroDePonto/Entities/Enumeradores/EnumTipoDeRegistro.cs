﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.Enumeradores
{
    public enum EnumTipoDeRegistro
    {
        ENTRADA = 1,
        SAIDA = 2
    }
}
