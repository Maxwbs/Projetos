﻿using Applications.Dtos;
using Entities.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Applications.Conversores
{
    public class ConversorRegistroDePonto : ConversorPadrao<RegistroDePonto, DtoRegistroDePonto> 
    {
    }
}
